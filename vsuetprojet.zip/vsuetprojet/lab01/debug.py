first = "2"
second = "3"
print("А: до преобразования:",
      f"first={type(first).__name__}, second={type(second).__name__}")
a = int(first)
b = int(second)
print("А: после преобразования:",
      f"a={type(a).__name__}, b={type(b).__name__}")
print(f"А: сумма = {a + b}")

age_str = input("Б: Возраст: ")
print(f"Б: до преобразования: age_str={type(age_str).__name__}")
age = int(age_str)
print(f"Б: после преобразования: age={type(age).__name__}")
print(f"Б: возраст через год = {age + 1}")

first_num = 4
second_num = 7
third_num = 10
average = (first_num + second_num + third_num) / 3
print(f"В: среднее = {average}")