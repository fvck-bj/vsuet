subject1 = input("Название 1-го предмета: ")
count1 = int(input(f"Занятий по «{subject1}» за неделю (целое >=0): "))
duration1 = int(input(f"Продолжительность занятия по «{subject1}», мин (целое >0): "))

subject2 = input("Название 2-го предмета: ")
count2 = int(input(f"Занятий по «{subject2}» за неделю (целое >=0): "))
duration2 = int(input(f"Продолжительность занятия по «{subject2}», мин (целое >0): "))

available_hours = float(input("Доступное время на неделю, часов: "))

if count1 < 0 or count2 < 0:
    print("Ошибка: количество занятий не может быть отрицательным.")
    raise SystemExit
if duration1 <= 0 or duration2 <= 0:
    print("Ошибка: продолжительность занятия должна быть положительной.")
    raise SystemExit

minutes1 = count1 * duration1
minutes2 = count2 * duration2
total_minutes = minutes1 + minutes2
total_hours = total_minutes / 60
free_hours = available_hours - total_hours

if free_hours < 0:
    print("Ошибка: доступное время меньше суммарной нагрузки.")
    raise SystemExit

print("=" * 46)
print("УЧЕБНАЯ НАГРУЗКА")
print("=" * 46)
print(f"{subject1}: {minutes1} мин")
print(f"{subject2}: {minutes2} мин")
print(f"Итого за неделю: {total_minutes} мин = {total_hours:.2f} ч")
print(f"Свободное время: {free_hours:.2f} ч")
print(f"Нагрузка за 4 недели: {total_hours * 4:.2f} ч")