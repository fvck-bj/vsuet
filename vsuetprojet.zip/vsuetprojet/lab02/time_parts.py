total_seconds = int(input("Общее число секунд (целое >= 0): "))

if total_seconds < 0:
    print("Ошибка: число секунд не может быть отрицательным.")
    raise SystemExit

hours = total_seconds // 3600
minutes = (total_seconds % 3600) // 60
seconds = total_seconds % 60

print(f"{hours} ч {minutes} мин {seconds} с")